# Goal-Tracker-Website #
Live Preview: https://goal-tracker.killiandebacker.com/

This website was built to learn React.

It works but needs heavy optimization.

# What I learned #
-Developed a website using the React Library to track goals over periods of time.

-Learned how mutation works and usage of functions that don't mutate.

-Learned React Lifecycle Methods such as componentDidMount and shouldComponentUpdate for utility and optimization.

-Used a linter to remove bad code and small mistakes.

# TODO: #
Add TODO Tracker.
